En la siguiente podremos encontrar el Machine Learning de Gonzalo Pérez Díez

La distribución del mismo es la siguiente:
	
	Código de entrenamiento de los modelos: src
	Código de testeo de los modelos: test_models
	Presentación del trabajo: presentacion
	Archivo adjunto con el enlace a GitHub: github.txt
	Memoria del proyecto y Documentación utilizada a lo largo del proyecto: Memoria_trabajo_ML.pdf
