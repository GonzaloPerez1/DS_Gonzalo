'''
Script principal del proyecto, todos los scripts están interconectados y desembocan en main.py
Para iniciar la descarga de los datos y el entrenamiento del modelo ejecutar en terminal:
`python main.py`
'''

from visualization import main_info

main_info()
