import pandas as pd

def get_data():
    pass