import pygame, sys

from pygame.locals import *
from random import choice, randint
from configuracion import *
from constantes import *
from utilidades import *

def completar_tablero (cursor, tablero, barco, sentido):

    return (-1,-1)

def actualizar_info_posicion (fila, columna, barco_actual):
    
    return False

def posicionar_barcos_enemigos(t):
    
    return None
    
def procesar_disparo(cursor, tablero, tablero2, dx, dy):
    
    return [] 

def disparo_enemigo(tablero, tablero2): 
    
    return []


def actualizar_tablero(info_disparos, disparos, jugada):
    	     
    return 0	    

